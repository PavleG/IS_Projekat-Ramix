package gui;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;

public class NoviRadniNalogController implements Initializable {

	@FXML
	private TableView<Detalji> table;
	
	@FXML
	private TextField datum;
	
	@FXML
	private TextField broj;
	
	@FXML
	private Button kreiraj;
	
	private static int id = 13;
	
	@FXML
	public void openUspesnoKreiranjeRadnogNaloga(Event e1) {
		try {
		id++;
		Stage stage1 = (Stage) kreiraj.getScene().getWindow();
	    stage1.close();
		FXMLLoader fxmlLoader= new FXMLLoader(getClass().getResource("UspesnoKreiranjeRadnogNaloga.fxml"));
		Parent root = (Parent) fxmlLoader.load();
		Stage stage = new Stage();
		stage.setTitle("Uspesno kreiranje!");
		
		
		
		stage.setScene(new Scene(root));
		stage.show();
		}
	 catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("Neuspelo ucitavanje novog prozora!");
	}
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		table.setEditable(true);
		
		DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy.");
		Date date = new Date();
		datum.setText(dateFormat.format(date));
		datum.setEditable(false);
		
		broj.setText(Integer.toString(id));
		broj.setEditable(false);

		Collection<Detalji> list;
		try {
			list = Files.readAllLines(new File("C:\\Users\\Filip\\eclipse-workspace\\Ramix GUI\\src\\detalji.txt").toPath())
			         .stream()
			         .map(line -> {
			             String[] details = line.split(",");
			             Detalji cd = new Detalji();
//			             if(details[0].trim().compareTo("123") != 0)
//			            	 return cd;
			             cd.setProizvod(details[1]);
			             cd.setKolicina(details[2]);
			             return cd;
			         })
			         .collect(Collectors.toList());


 ObservableList<Detalji> details = FXCollections.observableArrayList(list);

 TableColumn<Detalji, String> col1 = new TableColumn<>("Proizvod");
 TableColumn<Detalji, String> col2 = new TableColumn<>("Kolicina");

 table.getColumns().addAll(col1, col2);

 col1.setCellValueFactory(data -> data.getValue().getProizvod());
 col2.setCellValueFactory(data -> data.getValue().getKolicina());

 table.setItems(details);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}

}

package gui;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.util.Collection;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

public class ProizvodnjaKontroler implements Initializable {

	@FXML 
	public TableView<Porudzbina> porudzbine;
	
	public String getPorudzbine() {
		return porudzbine.getSelectionModel().getSelectedItem().uzmiSifra();
	}

	public void setPorudzbine(TableView<Porudzbina> porudzbine) {
		this.porudzbine = porudzbine;
	}


	@FXML 
	private TableView<Sirovina> sirovine;
	
	@FXML
	private Button detaljiOPorudzbini;
	
	@FXML
	private Button btn_radniNalog;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		 Collection<Porudzbina> list;
		 detaljiOPorudzbini.setDisable(true);
		 btn_radniNalog.setDisable(true);
		try {
			list = Files.readAllLines(new File("C:\\Users\\Filip\\eclipse-workspace\\Ramix GUI\\src\\porudzbine.txt").toPath())
			         .stream()
			         .map(line -> {
			             String[] details = line.split(",");
			             Porudzbina cd = new Porudzbina();
			             cd.setSifra(details[0]);
			             cd.setSifraKupca(details[1]);
			             cd.setAdresa(details[2]);
			             cd.setDatum(details[3]);
			             return cd;
			         })
			         .collect(Collectors.toList());


 ObservableList<Porudzbina> details = FXCollections.observableArrayList(list);

// tableView = new TableView<>();
 TableColumn<Porudzbina, String> col1 = new TableColumn<>("Sifra");
 TableColumn<Porudzbina, String> col2 = new TableColumn<>("Sifra Kupca");
 TableColumn<Porudzbina, String> col3 = new TableColumn<>("Adresa");
 TableColumn<Porudzbina, String> col4 = new TableColumn<>("Datum");

 porudzbine.getColumns().addAll(col1, col2, col3, col4);

 col1.setCellValueFactory(data -> data.getValue().getSifra());
 col2.setCellValueFactory(data -> data.getValue().getSifraKupca());
 col3.setCellValueFactory(data -> data.getValue().getAdresa());
 col4.setCellValueFactory(data -> data.getValue().getDatum());

 porudzbine.setItems(details);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		 Collection<Sirovina> list1;
			try {
				list1 = Files.readAllLines(new File("C:\\Users\\Filip\\eclipse-workspace\\Ramix GUI\\src\\sirovine.txt").toPath())
				         .stream()
				         .map(line -> {
				             String[] details = line.split(",");
				             Sirovina cd = new Sirovina();
				             cd.setSifraSirovine(details[0]);
				             cd.setNaziv(details[1]);
				             cd.setCena(details[2]);
				             cd.setKolicina(details[3]);
				             return cd;
				         })
				         .collect(Collectors.toList());


	 ObservableList<Sirovina> details = FXCollections.observableArrayList(list1);

	// tableView = new TableView<>();
	 TableColumn<Sirovina, String> col1 = new TableColumn<>("Sifra proizvoda");
	 TableColumn<Sirovina, String> col2 = new TableColumn<>("Naziv");
	 TableColumn<Sirovina, String> col3 = new TableColumn<>("Cena");
	 TableColumn<Sirovina, String> col4 = new TableColumn<>("Kolicina");

	 sirovine.getColumns().addAll(col1, col2, col3, col4);

	 col1.setCellValueFactory(data -> data.getValue().getSifraSirovine());
	 col2.setCellValueFactory(data -> data.getValue().getNaziv());
	 col3.setCellValueFactory(data -> data.getValue().getCena());
	 col4.setCellValueFactory(data -> data.getValue().getKolicina());

	 sirovine.setItems(details);

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		
	}
	
	@FXML
	public void onColumnClick() {
		if(!porudzbine.getSelectionModel().isEmpty())
		{
			detaljiOPorudzbini.setDisable(false);
			btn_radniNalog.setDisable(false);
		}
	}
	
	
	
	@FXML
	public void openDetaljiOPorudzbini(Event e1) {
		try {
		
			
		FXMLLoader fxmlLoader= new FXMLLoader(getClass().getResource("Detalji_o_porudzbini.fxml"));
		Parent root = (Parent) fxmlLoader.load();
		Stage stage = new Stage();
		stage.setTitle("Detalji o porud�bini");
		
		
		
		stage.setScene(new Scene(root));
		stage.show();
		}
	 catch (IOException e) {
		// TODO Auto-generated catch block
		//e.printStackTrace();
		System.out.println("Neuspelo ucitavanje novog prozora!");
	}
	}

	
	public void napraviRadniNalog(Event e1) {
		
		try {
		
			
		FXMLLoader fxmlLoader= new FXMLLoader(getClass().getResource("Novi_radni_nalog.fxml"));
		Parent root = (Parent) fxmlLoader.load();
		Stage stage = new Stage();
		stage.setTitle("Novi radni nalog");
		stage.setScene(new Scene(root));
		stage.show();
		}
	 catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		System.out.println("Neuspelo ucitavanje novog prozora!");
	}
		
	}

}

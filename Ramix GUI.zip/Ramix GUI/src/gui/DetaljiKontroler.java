package gui;

import java.io.File;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.util.Collection;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import gui.ProizvodnjaKontroler;
public class DetaljiKontroler implements Initializable{

	@FXML
	private TableView<Detalji> detalji;
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		Collection<Detalji> list;
		try {
			list = Files.readAllLines(new File("C:\\Users\\Filip\\eclipse-workspace\\Ramix GUI\\src\\detalji.txt").toPath())
			         .stream()
			         .map(line -> {
			             String[] details = line.split(",");
			             Detalji cd = new Detalji();
//			             if(details[0].trim().compareTo()) != 0)
//			            	 return cd;
			             cd.setProizvod(details[1]);
			             cd.setKolicina(details[2]);
			             return cd;
			         })
			         .collect(Collectors.toList());


 ObservableList<Detalji> details = FXCollections.observableArrayList(list);

 TableColumn<Detalji, String> col1 = new TableColumn<>("Proizvod");
 TableColumn<Detalji, String> col2 = new TableColumn<>("Kolicina");

 detalji.getColumns().addAll(col1, col2);

 col1.setCellValueFactory(data -> data.getValue().getProizvod());
 col2.setCellValueFactory(data -> data.getValue().getKolicina());

 detalji.setItems(details);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	

}

package gui;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Detalji {
	
	
	public StringProperty proizvod = new SimpleStringProperty();
	public StringProperty kolicina = new SimpleStringProperty();
	
	
	public StringProperty getProizvod() {
		return this.proizvod;
	}

	public String uzmiProizvod() {
		return this.getProizvod().get();
	}
	
	public void setProizvod(String proizvod) {
		this.getProizvod().set(proizvod);
	}

	public StringProperty getKolicina() {
		return this.kolicina;
	}

	public String uzmiKolicina() {
		return this.getKolicina().get();
	}
	
	public void setKolicina(String kolicina) {
		this.getKolicina().set(kolicina);
	}
	
	
	

}
